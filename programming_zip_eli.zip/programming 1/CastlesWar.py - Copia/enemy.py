import pygame

# Enemy class
class Enemy(pygame.sprite.Sprite):
    # For sword1
    def __init__(self, health, animation_list, x, y, speed):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.speed = speed = 2
        self.health = health
        self.animation_list = animation_list
        self.frame_index = 0
        self.action = 0 #0: run, 1: attack, 2: fallen
        self.update_time = pygame.time.get_ticks()

        # Select starting image
        self.image1 = self.animation_list[self.action][self.frame_index]
        self.rect1 = self.image1.get_rect()
        self.rect1.center = (x, y)


    def update(self, surface, target):
        # Check if the enemy has reached the wall
        if self.rect1.right > target.rect.left:
            self.update_action(1) 
        
        # Move sword
        if self.action == 0:
            # Update his position
            self.rect1.x += self.speed 
    def move(self, start_walking):
        # Reset movement variable
        dx = 0 
        dy = 0 

        if start_walking:
            dx = self.speed

        self.rect1.x += dx
        self.rect1.y += dy


        self.update_animation1()
        # Draw image on screen 
        pygame.draw.rect(screen, (255, 255, 255), self.rect1, 1)
        screen.blit(self.image1, self.rect1)

    def update_animation1(self):
        # Define animation cooldown
        ANIMATION_COOLDOWN = 70 
        # Update image depending on current action
        self.image1 = self.animation_list[self.action][self.frame_index]
        # Check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        # if the animation runs out, resent back to the beginning
        if self.frame_index >= len(self.animation_list[self.action]):
            self.frame_index = 0

    def update_action(self, new_action):
        # Check if the new action is different from the previous one
        if new_action != self.action:
            self.action = new_action
            # Update animation setting
            self.frame_index = 0
            self.update_date = pygame.time.get_ticks()
    
    # For sword2
    
# Create enemies
sword1 = Enemy(enemy_health[0], enemy_animations[0], 106, SCREEN_HEIGHT - 10, 7)
sword2 = Enemy(enemy_health[0], enemy_animations[0], SCREEN_WIDTH - 106, SCREEN_HEIGHT - 10, 7)
enemy_group = pygame.sprite.Group()
enemy_group.add(sword1)
enemy_group.add(sword2)