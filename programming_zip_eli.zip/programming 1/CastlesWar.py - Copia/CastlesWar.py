# CastlesWar by Elisa Totis

# Import libraries
import pygame
import math 


# Initialize the pygame
pygame.init()

# Create the screen
SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 250
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Set time
clock = pygame.time.Clock()
FPS = 60

# Caption and icon
pygame.display.set_caption('Castles War by Elisa Totis')
icon = pygame.image.load('castle.png.png')
pygame.display.set_icon(icon)

# Background 
#background = pygame.image.load('background.png').convert_alpha()

# Load images
# Player 1 (red)
# Buildings
wall_red_img = pygame.image.load('wall1.png').convert_alpha() #image1
tower1_img = pygame.image.load('tower1.png').convert_alpha() #image12
barracks1_img = pygame.image.load('barracks1.png').convert_alpha() #image13
mine1_img = pygame.image.load('mine1.png').convert_alpha() #image14
# Bow
arrowdiag01_img = pygame.image.load('arrowdiag0.1.png').convert_alpha() #image15
arrowdiag11_img = pygame.image.load('arrowdiag1.1.png').convert_alpha() #image16
arrowhor01_img = pygame.image.load('arrowhor0.1.png').convert_alpha() #image17
arowhor11_img = pygame.image.load('arrowhor1.1.png').convert_alpha() #image18
arrowvert01_img = pygame.image.load('arrowvert0.1.png').convert_alpha() #image19
arrowvert11_img = pygame.image.load('arrowvert1.1.png').convert_alpha() #image110
fallen01_img = pygame.image.load('fallen0.1.png').convert_alpha() #image120
fallen11_img = pygame.image.load('fallen1.1.png').convert_alpha() #image130
fallen21_img = pygame.image.load('fallen2.1.png').convert_alpha() #image140
fallen31_img = pygame.image.load('fallen3.1.png').convert_alpha() #image150
fallen41_img = pygame.image.load('fallen4.1.png').convert_alpha() #image160
fallen51_img = pygame.image.load('fallen5.1.png').convert_alpha() #image170
ready1_img = pygame.image.load('ready.1.png').convert_alpha() #image180
run01_img = pygame.image.load('run0.1.png').convert_alpha() #image190
run11_img = pygame.image.load('run1.1.png').convert_alpha() #image110
run21_img = pygame.image.load('run2.1.png').convert_alpha() #image111
run31_img = pygame.image.load('run3.1.png').convert_alpha() #image112
run41_img = pygame.image.load('run4.1.png').convert_alpha() #image113
run51_img = pygame.image.load('run5.1.png').convert_alpha() #image114
run61_img = pygame.image.load('run6.1.png').convert_alpha() #image115
run71_img = pygame.image.load('run7.1.png').convert_alpha() #image116
run81_img = pygame.image.load('run8.1.png').convert_alpha() #image117
run91_img = pygame.image.load('run9.1.png').convert_alpha() #image118
run101_img = pygame.image.load('run10.1.png').convert_alpha() #image119
run111_img = pygame.image.load('run11.1.png').convert_alpha() #image12
shoot01_img = pygame.image.load('shoot0.1.png').convert_alpha()
shoot11_img = pygame.image.load('shoot1.1.png').convert_alpha()

# Define game variables
SWORD_TRAIN = 20 
last_enemy = pygame.time.get_ticks()

# Enemies
enemy_animations_red = []
enemy_animations_blue = []
enemy_types = ['sword']
enemy_health = [30]
animation_types = ['run', 'attack', 'fallen']
num_of_frames = {'run': 11, 'attack': 7, 'fallen': 6}
# Sword
for enemy in enemy_types:
    # Load animation
    animation_list_red = []
    animation_list_blue = []
    for animation in animation_types:
        # Reset temporary list of images
        temp_list_red = []
        temp_list_blue = []
        # Define number of frames
        #num_of_frames = 6 #da sistemare numero frames!!!!!!
        for i in range(num_of_frames[animation]):
            img1 = pygame.image.load(f'player1/{enemy}/{animation}/{i}.png').convert_alpha()
            img2 = pygame.image.load(f'player2/{enemy}/{animation}/{i}.png').convert_alpha()
            temp_list_red.append(img1)
            temp_list_blue.append(img2)
        animation_list_red.append(temp_list_red)
        animation_list_blue.append(temp_list_blue)
    enemy_animations_red.append(animation_list_red)
    enemy_animations_blue.append(animation_list_blue)



# Player 2 (blu)
wall_blue_img = pygame.image.load('wall2.png').convert_alpha() #image2
tower2_img = pygame.image.load('tower2.png').convert_alpha() #image22
barracks2_img = pygame.image.load('barracks2.png').convert_alpha() #image23
mine2_img = pygame.image.load('mine2.png').convert_alpha() #image24
# Bow
arrowdiag02_img = pygame.image.load('arrowdiag0.2.png').convert_alpha() #image15
arrowdiag12_img = pygame.image.load('arrowdiag1.2.png').convert_alpha() #image16
arrowhor02_img = pygame.image.load('arrowhor0.2.png').convert_alpha() #image17
arowhor12_img = pygame.image.load('arrowhor1.2.png').convert_alpha() #image18
arrowvert02_img = pygame.image.load('arrowvert0.2.png').convert_alpha() #image19
arrowvert12_img = pygame.image.load('arrowvert1.2.png').convert_alpha() #image110
fallen02_img = pygame.image.load('fallen0.2.png').convert_alpha() #image120
fallen12_img = pygame.image.load('fallen1.2.png').convert_alpha() #image130
fallen22_img = pygame.image.load('fallen2.2.png').convert_alpha() #image140
fallen32_img = pygame.image.load('fallen3.2.png').convert_alpha() #image150
fallen42_img = pygame.image.load('fallen4.2.png').convert_alpha() #image160
fallen52_img = pygame.image.load('fallen5.2.png').convert_alpha() #image170
ready2_img = pygame.image.load('ready2.png').convert_alpha() #image180
run02_img = pygame.image.load('run0.2.png').convert_alpha() #image190
run12_img = pygame.image.load('run1.2.png').convert_alpha() #image110
run22_img = pygame.image.load('run2.2.png').convert_alpha() #image111
run32_img = pygame.image.load('run3.2.png').convert_alpha() #image112
run42_img = pygame.image.load('run4.2.png').convert_alpha() #image113
run52_img = pygame.image.load('run5.2.png').convert_alpha() #image114
run62_img = pygame.image.load('run6.2.png').convert_alpha() #image115
run72_img = pygame.image.load('run7.2.png').convert_alpha() #image116
run82_img = pygame.image.load('run8.2.png').convert_alpha() #image117
run92_img = pygame.image.load('run9.2.png').convert_alpha() #image118
run102_img = pygame.image.load('run10.2.png').convert_alpha() #image119
run112_img = pygame.image.load('run11.2.png').convert_alpha() #image12
shoot02_img = pygame.image.load('shoot0.2.png').convert_alpha()
shoot12_img = pygame.image.load('shoot1.2.png').convert_alpha()



# Define colours
WHITE = (255, 255, 255)

# wall_red class, Player 1
class wall_red:
        
        #WALL_POS = 180      # horizontal coordinate of the center of the wall
        #WALL_WIDTH = 62     # width of the wall
        #WALL_HEIGHT = 80    # height of the wall

    def __init__(self, image1, x, y, scale):
        
        self.WALL_HEALTH = 1000 # maximum amount of HP af the wall
        self.max_WALL_HEALTH = self.WALL_HEALTH

        width = image1.get_width()
        height = image1.get_height()

        self.image1 = pygame.transform.scale(image1, (int(width * scale), int(height * scale)))
        self.rect = self.image1.get_rect()
        self.rect.x = x 
        self.rect.y = y 

    def draw(self):
        self.image = self.image1
        screen.blit(self.image, self.rect)

# Create wall_red
wall_red = wall_red(wall_red_img, 149, 170, 1)

    
# wall_blue class, Player 2
class wall_blue():
    def __init__(self, image2, x, y, scale):
        self.WALL_HEALTH = 1000 # maximum amount of HP af the wall
        self.max_WALL_HEALTH = self.WALL_HEALTH

        width = image2.get_width()
        height = image2.get_height()

        self.image2 = pygame.transform.scale(image2, (int(width * scale), int(height * scale)))
        self.rect = self.image2.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image2
        screen.blit(self.image, self.rect)

# Create wall_blue
wall_blue = wall_blue(wall_blue_img, 790, 170, 1)
 

# Tower1 class, Player 1
class Tower1():
    def __init__(self, image12, x, y, scale):
        self.fired = False
        width = image12.get_width()
        height = image12.get_height()

        self.image12 = pygame.transform.scale(image12, (int(width * scale), int(height * scale)))
        self.rect = self.image12.get_rect()
        self.rect.x = x 
        self.rect.y = y 
      
    def shoot(self):
        pos = pygame.mouse.get_pos()
        x_dist = pos[0] - self.rect.midtop[0]
        y_dist = -(pos[1] - self.rect.midtop[1])
        self.angle = math.degrees(math.atan2(y_dist, x_dist))
        
        # Get mouseclick
        if pygame.mouse.get_pressed()[0] and self.fired == False:
            self.fired = True
            arrowdiag01 = Arrowdiag01(arrowdiag01_img, self.rect.midtop[0], self.rect.midtop[1], self.angle)
            arrowdiag01_group.add(arrowdiag01)
        #reset mousclick
        if pygame.mouse.get_pressed()[0] == False:
            self.fired = False
        #pygame.draw.line(screen, WHITE, (self.rect.midtop[0], self.rect.midtop[1]), (pos))


    def draw(self):
        self.image = self.image12
        screen.blit(self.image, self.rect)

# Create Tower1
tower1 = Tower1(tower1_img, 154, 90, 1)
   
# Arrowdiag01 class:
class Arrowdiag01(pygame.sprite.Sprite):
    def __init__ (self, image01, x, y, angle):
        pygame.sprite.Sprite.__init__(self)
        self.image = image01
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.angle = math.radians(angle) #convert input angle into radians
        self.speed = 10 

    def update(self):

        #move bullet
        self.rect.x >= 220
        self.rect.y >= 0
# Create groups
arrowdiag01_group = pygame.sprite.Group()


# Tower2 class, Player 2
class Tower2():
    def __init__(self, image22, x, y, scale):

        width = image22.get_width()
        height = image22.get_height()

        self.image22 = pygame.transform.scale(image22, (int(width * scale), int(height * scale)))
        self.rect = self.image22.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image22
        screen.blit(self.image, self.rect)

# Create Tower2
tower2 = Tower2(tower2_img, 794, 90, 1)
 

# Barracks1 class, Player 1
class Barracks1():
    def __init__(self, image13, x, y, scale):

        width = image13.get_width()
        height = image13.get_height()

        self.image13 = pygame.transform.scale(image13, (int(width * scale), int(height * scale)))
        self.rect = self.image13.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image13
        screen.blit(self.image, self.rect)    

# Create Barracks1
barracks1 = Barracks1(barracks1_img, 75, 200, 1)


# Barracks2 class, Player 2
class Barracks2():
    def __init__(self, image23, x, y, scale):

        width = image23.get_width()
        height = image23.get_height()

        self.image23 = pygame.transform.scale(image23, (int(width * scale), int(height * scale)))
        self.rect = self.image23.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image23
        screen.blit(self.image, self.rect)    

# Create Barracks1
barracks2 = Barracks2(barracks2_img, 863, 200, 1)


# Mine1 class, Player 1
class Mine1():
    def __init__(self, image14, x, y, scale):

        width = image14.get_width()
        height = image14.get_height()

        self.image14 = pygame.transform.scale(image14, (int(width * scale), int(height * scale)))
        self.rect = self.image14.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image14
        screen.blit(self.image, self.rect)    

# Create Mine1
mine1 = Mine1(mine1_img, 11, 213, 1)

# Mine2 class, Player 2
class Mine2():
    def __init__(self, image24, x, y, scale):

        width = image24.get_width()
        height = image24.get_height()

        self.image24 = pygame.transform.scale(image24, (int(width * scale), int(height * scale)))
        self.rect = self.image24.get_rect()
        self.rect.x = x 
        self.rect.y = y 
        
    def draw(self):
        self.image = self.image24
        screen.blit(self.image, self.rect)    

# Create Mine2
mine2 = Mine2(mine2_img, 930, 213, 1)

# Sword class
# Sword red
class Sword_red(pygame.sprite.Sprite):
   
    def __init__(self, health, animation_list_red, x, y, speed):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.speed = speed = 2
        self.health = 30
        self.animation_list_red = animation_list_red
        self.frame_index = 0
        self.action = 0 #0: run, 1: attack, 2: fallen
        self.update_time = pygame.time.get_ticks()
        self.hit = 2

        # Select starting image
        self.image1 = self.animation_list_red[self.action][self.frame_index]
        self.rect = self.image1.get_rect()
        self.rect.center = (x, y)


    def update(self, surface, target):
        
        # Check if the enemy has reached the wall
        for element in target:
            if self.rect.right > element.rect.left:
                self.update_action(1) 
                element.health = element.health - 30
                if element.health == 0:
                    element.update_action(2)
                    target.remove(element)
                    target_for_red = target
                    print(target)
                    enemy_group_red.update(screen, target)
                    pygame.display.update()
                    break
        
        # Move sword
        if self.action == 0:
            # Update his position
            self.rect.x += self.speed 

        # Check if health is zero
        if self.health <= 0:
            self.update_action(2)
   
    def move(self, start_walking):
        # Reset movement variable
        dx = 0 
        dy = 0 

        if start_walking:
            dx = self.speed

        self.rect.x += dx


        self.update_animation1()
        # Draw image on screen 
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 1)
        screen.blit(self.image1, self.rect)

    def update_animation1(self):
        # Define animation cooldown
        ANIMATION_COOLDOWN = 70 
        # Update image depending on current action
        self.image1 = self.animation_list_red[self.action][self.frame_index]
        # Check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        # if the animation runs out, resent back to the beginning
        if self.frame_index >= len(self.animation_list_red[self.action]):
            self.frame_index = 0

    def update_action(self, new_action):
        # Check if the new action is different from the previous one
        if new_action != self.action:
            self.action = new_action
            # Update animation setting
            self.frame_index = 0
            self.update_date = pygame.time.get_ticks()
    
    # For sword blue
class Sword_blue(pygame.sprite.Sprite):

    def __init__(self, health, animation_list_blue, x, y, speed):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.speed = speed = 2
        self.health = health
        self.animation_list_blue = animation_list_blue
        self.frame_index = 0
        self.action = 0 #0: run, 1: attack, 2: fallen
        self.update_time = pygame.time.get_ticks()

        # Select starting image
        self.image2 = self.animation_list_blue[self.action][self.frame_index]
        self.rect = self.image2.get_rect()
        self.rect.center = (x, y)


    def update(self, surface, target):
        #target = []
        # Check if the enemy has reached the wall
        for element in target:
            if self.rect.left < element.rect.right:
                self.update_action(1) 

        # Move sword
        if self.action == 0:
            # Update his position
            self.rect.x -= self.speed 

    def move(self, start_walking):
        # Reset movement variable
        dx = 0 
        dy = 0 

        if start_walking:
            dx = self.speed

        self.rect.x -= dx


        self.update_animation1()
        # Draw image on screen 
        pygame.draw.rect(screen, (255, 255, 255), self.rect, 1)
        screen.blit(self.image2, self.rect)

    def update_animation1(self):
        # Define animation cooldown
        ANIMATION_COOLDOWN = 70 
        # Update image depending on current action
        self.image2 = self.animation_list_blue[self.action][self.frame_index]
        # Check if enough time has passed since the last update
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        # if the animation runs out, resent back to the beginning
        if self.frame_index >= len(self.animation_list_blue[self.action]):
            self.frame_index = 0

    def update_action(self, new_action):
        # Check if the new action is different from the previous one
        if new_action != self.action:
            self.action = new_action
            # Update animation setting
            self.frame_index = 0
            self.update_date = pygame.time.get_ticks()
    
    
# Create enemies
sword1 = Sword_red(enemy_health[0], enemy_animations_red[0], 106, SCREEN_HEIGHT - 10, 7)
sword2 = Sword_blue(enemy_health[0], enemy_animations_blue[0], SCREEN_WIDTH - 106, SCREEN_HEIGHT - 10, 7)
enemy_group_red = pygame.sprite.Group()
enemy_group_blue = pygame.sprite.Group()
enemy_group_red.add(sword1)
enemy_group_blue.add(sword2)


# Define player action variables
start_walking = False

# Game Loop
running = True
sword1_walk = False
sword2_walk = False
target_for_blue = [wall_red, sword1]
target_for_red = [wall_blue, sword2]

while running:
    
    # Screen
    screen.fill((0, 0, 0))

    # Frame per seconds
    clock.tick(FPS)
    
    # Draw castle, Player 1

    tower1.draw()
    tower1.shoot()
    tower2.draw()
    wall_red.draw()
    wall_blue.draw()
    barracks1.draw()
    barracks2.draw()
    mine1.draw()
    mine2.draw()
    key = pygame.key.get_pressed()

    if key[pygame.K_d]:
        sword1_walk = True
        
    if sword1_walk == True:
        sword1.move(start_walking)
        enemy_group_red.update(screen, target_for_red)

    if key[pygame.K_j]:
        sword2_walk = True
        
    if sword2_walk == True:
        #dx = sword2.speed
        sword2.move(start_walking)
        enemy_group_blue.update(screen, target_for_blue)

    # Draw bullets
    arrowdiag01_group.update()
    arrowdiag01_group.draw(screen)


    # Event handler
    for event in pygame.event.get():
    	if event.type == pygame.QUIT:
    		running = False
    
    # Update the display window
    pygame.display.update()


pygame.quit()
