import pygame
import random

#initialize the pygame
pygame.init()

#create the screen 
screen = pygame.display.set_mode((800,600))

#Title and Icon personalized
#title
pygame.display.set_caption('Space Invaders')

#icon, search an image on flaticon.com (non la riconosce nel dekstop)
#icon = pygame.image.load('spaceinvader.png')
#pygame.display.set_icon(icon)

#player
playerImg = pygame.image.load('spaceship.png')
playerX = 370
playerY = 480
playerX_change = 0

#enemy
enemyImg = pygame.image.load('enemy.png')
enemyX = random.randint(0,800)
enemyY = random.randint(50, 150)
enemyX_change = 0

#we want the player to appear in a certain point on the screen
def player(x, y):
	screen.blit(playerImg, (x, y))
def enemy(x, y):
	screen.blit(enemyImg, (x, y))

#to make the window open for more than a second and 
#to be able to close the window
#to change the background
running = True
while running:
	
	#RGB (red, greeb, blue)
    screen.fill((0, 0, 0))
    playerX -= 0.2
    print(playerX)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
	        running = False 

	#if keystroke is pressed check whether is right or left
    if event.type == pygame.KEYDOWN:
	    if event.key == pygame.K_LEFT:
		    playerX_change = -0.3
	    if event.key == pygame.K_RIGHT:
		    playerX_change = +0.3
    if event.type == pygame.KEYUP:
	    if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
		    playerX_change = 0

playerX += playerX_change

#adding boundaries
if playerX <=0:
	playerX = 0
elif playerX >=736:
	playerX = 736

player(playerX, playerY)
enemy(enemyX, enemyY)
pygame.display.update()

